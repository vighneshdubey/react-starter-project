import React from 'react';
import ReactDOM from 'react-dom';
  
const title = 'Your awesome React app';
  
ReactDOM.render(
  <div>{title}</div>,
  document.getElementById('app')
);